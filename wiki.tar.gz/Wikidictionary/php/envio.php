<?php
	include("conexiondb.php");
	session_start();


	$email = $_POST["correo"];
	$contrasenia = $_POST["contrasenia"];

	$sql= "select nombre, apellidos from usuario where id_usuario = '".$email."' and password = '".$contrasenia."'";
	$resultado = mysqli_query($conexion, $sql);

	if(mysqli_num_rows($resultado) == 1){

		$linea = mysqli_fetch_array($resultado);

		$nombre = $linea[0];
		$_SESSION['nombre']=$nombre;


		$apellidos = $linea[1];
		$_SESSION['apellido']=$apellidos;

		
		echo true;
		
	}else{
		echo false;
	}

		mysqli_close($conexion);
		//session_destroy();
		//mysqli_close($conexion);


		//header("location: ../");
		//echo "<script>javascript:window.history.back(); </script>";
?>