<?php
 
$server = "localhost";
$username = "root";
$password = "4rx231";
$database = "wikiusuarios";
 
$con = mysql_connect($server, $username, $password) or die ("No se conecto: " . mysql_error());
 
mysql_select_db($database, $con);
 
$usu = mysql_real_escape_string($_POST["correo"]);
$pass = mysql_real_escape_string($_POST["contrasenia"]);
 
$sql = "SELECT nombre FROM usuario WHERE id_usuario='$usu' AND password='$pass'";
 
if ($resultado = mysql_query($sql, $con)){
    if (mysql_num_rows($resultado) > 0){
        echo true;
    }
}
else{
    echo false;
}
mysql_close($con);
 
?>