<?php
	header("location:../");
?>