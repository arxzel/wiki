<?php
	include("conexiondb.php");
	session_start();
	
	echo "bienvenido señor ".$_SESSION['nombre'];

?>